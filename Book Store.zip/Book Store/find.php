<?php

$user='root';
$pass='';
$db='book_store';

$conn=mysqli_connect("localhost","root","");
mysqli_select_db($conn,"book_store");
$output ='';
//collect
if(isset($_POST['search'])){
	$searchq=$_POST['search'];
		$searchq=preg_replace("#[^0-9a-z ]#i","",$searchq);
	$query=mysqli_query($conn,"SELECT * FROM book WHERE name LIKE '$searchq%' OR writter LIKE '$searchq%' ")or die("could not search!");
		$count=mysqli_num_rows($query);
		if($count==0){
			$output='There was no search results!';
		}else{
			while($row=mysqli_fetch_array($query)){
				$fname=$row['name'];
					$lname=$row['writter'];
				$id=$row['book_id'];
						$output .='<div>'.$fname.' '.$lname.'</div>';
			}
		}
}
?> 

<html>
<head>
<title>
Search
</title>
</head>
<body>
<form action="find.php"method="POST">
<input type="text" name="search"placeholder="Search for writer..."/>
<input type="submit" value=">>"/>
</form>

<?php print("$output");?>
</body>
</html>