<html>
<head>
<style type="text/css">

ul{
list-style-type:none;
margin:0;
padding:0;
overflow:hidden;
}


a:link,a:visited{
display:block;
color:blue;
background-color:#72e47b; 
width:120px;
text-align:center;
padding:6px;
text-transform:uppercase;
text-decoration:none;
}


a:hover{color:#7A991A;background-color:green;font-weight:bold;font-size:120%}
	a:active{color:red;}

li{
float:left;
}


#wrapper{
    width:100%;
	height:100%;
	background-color:#e0ffff;
	font-family:elephant; 
	}

	
#banner{
    width:100%;
	height:25%;
	background-color:#e0ffff;
	font-family:elephant;
	 color:black;
	}

#menutop{
    width:110%;
	height:8%;
	background-color:#33CCbb;
	}

#columnleft{
    width:20%;
	height:70%;
	background-color:#CC44bb;
	float:left;
	text-align:center;
font-size:30;
 font-family:elephant;
 
	}	
	
#columnright{
    width:20%;
	height:70%;
	background-color:#b0c4de;
	float:right;
	}	
	
#content{
    width:70%;
	height:70%;
	background-color:pink;
	margin-left:220px;
	}
	
	
#footer{
    width:100%;
	height:10%;
	background-color:#336633;
	text-align:center;
font-size:30;
 font-family:elephant;
	}
		


</style>

<script type="text/javascript">
var inc=1;
function changeImages(){
var objImage=document.getElementById("IMG");
inc=inc+1;
objImage.src="newImages/a("+inc+").jpg";
if(inc==5){
inc=0;
}
}
var tmr=setInterval(changeImages,1000);
</script>
</head>	
<body>



<div id="wrapper">

     <div id="banner">
	 <center><h1>Progga's Book Store</h1></center>
    </div>

    <div id="menutop">
	
	<ul>
<li><a href="home.php">HOME</a></li>
<li><a href="subject.php">Subject</a></li>
     
<li><a href="writer.php">Writer</a></li>
<li><a href="publisher.html">Publisher</a></li>
<li><a href="order.php">Pre order book</a></li>
<li><a href="mostbook.html">Most sell out book</a></li>
<li><a href="disbook.html">Discount book</a></li>
<li><a href="chibook.html">Children book</a></li>
<li><a href="way.html">Way of getting book</a></li>
<li><a href="contact.html">Contact</a></li>
</ul>
    </div>

    <div id="columnleft">
	Featured books
	<div style="float:left;height:40%;weight:1px;background-color:white">
	
	<img src="boyl.jpg" style="height:100%; width:90%;">
</div>

<div style="float:left;height:50%;weight:1px;background-color:pink">


	Electronic Device And Circuit Theory

	price:$118.20
	
	<div style="float:right;height:10%;weight:1px;background-color:#AAA;font-size:18;">

<a href="view.html">details</a>
</div>

</div>
    </div>

    <div id="columnright">
    </div>

    <div id="content">
	<img src="newImages/a(1).jpg" id="IMG" style="width:85%;height:100%;"/>
    </div>
    
	<div id="footer">
	<marquee>Welcome to my website</marquee>
    </div>
    


</div>




	
	</body>
	</html>
	