<html>

<head>
<title>BOOK STORE</title>
<style>
.phpcoding{width:900px;margin:0 auto;background:<?php echo "#ddd"?>;}
.header,.footer{background:violet;color:#fff;text-align:center;padding:20px}.header h2,.footer h2{margin:0}
.middle{min-height:400px;}
</style>
</head>

<body>
<div class="phpcodding">
   <section class ="header">
   <h1><marquee>Hi Welcome This Book Store</marquee></h1>
   </section>
   
		
		<section class="middle">
		 <img src="book.jpg" style="height:400px; width:500px;float:left;">
				 <img src="pp.jpg" style="height:400px; width:300px;float:center;">
		 <img src="stall.jpg" style="height:400px; width:500px;float:right;">
		  </section>
<section class="footer">
     <h2>Please GO to my website <a href="home.php">go to</a></h2>
	  </section>
</div>
</body>
</html>	  
 

