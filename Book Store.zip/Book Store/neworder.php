<html>
<head>
<title>home(Book Store)</title>
<style type="text/css">

#start{
background-color:black;
color:pink;
height:20%;
width:100%;
text-align:center;
font-size:40;
 font-family:elephant;
}
  
  
ul{

margin:0px;
padding:0px;
list-style:none;
}




ul li{
	float:left;
	width: 10%;
	height:40px;
	background-color:white; 
	 line-height:40px;
	text-align:center;
	font-size:20px; 
	font-family:Berlin Sans FB;
	margin-right:0px;
	
	}
	
	ul li a{
	text-decoration:none;
	color:brown;
		display:block;
		}


	ul li a:hover{
		background-color:blue;}




ul li ul li{
display:none;
}
ul li:hover ul li{
display:none;
}



a:link,a:visited{
display:block;
color:#FFFFFF;
background-color:#72e47b; 
width:120px;
text-align:center;
padding:5px;
text-transform:uppercase;
text-decoration:none;
}


a:hover{color:#7A991A;font-weight:bold;font-size:110%}
	a:active{color:red;}

li{
float:left;
}










</style>
</head>






<body>

<div id="start">
			Progga's Book Store
			<br>(Subject)</br>
</div>


<ul>
<li><a href="home.php">HOME</a></li>
<li><a href="subject.php">Subject</a></li>
     
<li><a href="writer.html">Writer</a></li>
<li><a href="publisher.html">Publisher</a></li>
<li><a href="order.php">Pre order book</a></li>
<li><a href="mostbook.html">Most sell out book</a></li>
<li><a href="disbook.html">Discount book</a></li>
<li><a href="chibook.html">Children book</a></li>
<li><a href="way.html">Way of getting book</a></li>
<li><a href="contact.html">Contact</a></li>
</ul>

<br>
<br>
<br>
</br>
<center>
<h1>Order list</h1>

<table>
<form action="ordr.php"method="POST">

<tr><td>Book id:</td><td><input type ="text" name="number"/><br/></td><td>
<tr><td>payment id:</td><td><input type ="text" name="word"/><br/></td><td>
<tr><td>Each book price:</td><td><input type ="text" name="number"/><br/></td><td>
<tr><td>Quantity:</td><td><input type ="text" name="number"/><br/></td><td>
<tr><td>Discount:</td><td><input type ="text" name="number"/><br/></td><td>
<tr><td>Total:</td><td><input type ="text" name="number"/><br/></td><td>
<tr><td>Order date:</td><td><input type ="text" name="word"/><br></td><td>
<tr><td>Payment date:</td><td><input type ="text" name="word"/><br/></td><td>
</table>

<input type="submit" value="Submit">
 
</form>

</center>


	


		
		
		

</body>
</html>