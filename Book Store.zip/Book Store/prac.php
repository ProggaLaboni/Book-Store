<html>
<head>
<title>home(Book Store)</title>

</head>
<body>


<div class="start">

Home
</div>




<div class="topnav">

a:link{color:blue;}
	a:visited{color:yellow;}
	a:hover{color:green;font-weight:bold;font-size:900%}
	a:active{color:red;}


<a href="home1.html" >Home</a>
<a href="education1.html" >Event</a>
<a href="galary1.html" >Writer</a>
<a href="contact1.html"  >Subject</a>
<a href="skill1.html" >Publisher</a>
<a href="skill1.html" >Pre order book</a>
<a href="skill1.html" >Most sell out book</a>
<a href="skill1.html" >Discount book</a>
<a href="skill1.html" >Children book</a>
<a href="skill1.html" >Way of getting books</a>
<a href="skill1.html" >Contact</a>

</div>

		
		
		<div style="height:80%;width:100%;"><img src="boi.jpg"height="600px" width="500px;float:left;">
		<img src="bb.jpg"height="600px" width="400px;float:left;">
				<img src="store.jpg"height="600px" width="400px;float:right;">
		</div>

		

</body>
</html>