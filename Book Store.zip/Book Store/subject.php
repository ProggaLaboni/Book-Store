<html>
<head>
<title>home(Book Store)</title>
<style type="text/css">

#start{
background-color:black;
color:pink;
height:20%;
width:100%;
text-align:center;
font-size:40;
 font-family:elephant;
}
  
  
ul{

margin:0px;
padding:0px;
list-style:none;
}




ul li{
	float:left;
	width: 10%;
	height:40px;
	background-color:white; 
	 line-height:40px;
	text-align:center;
	font-size:20px; 
	font-family:Berlin Sans FB;
	margin-right:0px;
	
	}
	
	ul li a{
	text-decoration:none;
	color:brown;
		display:block;
		}


	ul li a:hover{
		background-color:blue;}




ul li ul li{
display:none;
}
ul li:hover ul li{
display:none;
}



a:link,a:visited{
display:block;
color:#FFFFFF;
background-color:#72e47b; 
width:120px;
text-align:center;
padding:5px;
text-transform:uppercase;
text-decoration:none;
}


a:hover{color:#7A991A;font-weight:bold;font-size:110%}
	a:active{color:red;}

li{
float:left;
}










</style>
</head>






<body>

<div id="start">
			Progga's Book Store
			<br>(Subject)</br>
</div>


<ul>
<li><a href="home.php">HOME</a></li>
<li><a href="subject.php">Subject</a></li>
     
<li><a href="writer.php">Writer</a></li>
<li><a href="publisher.php">Publisher</a></li>
<li><a href="order.php">Pre order book</a></li>
<li><a href="mostbook.php">Most sell out book</a></li>
<li><a href="disbook.php">Discount book</a></li>
<li><a href="chibook.php">Children book</a></li>
<li><a href="way.php">Way of getting book</a></li>
<li><a href="contact.php">Contact</a></li>
</ul>

<br>
<br>
<br>
<center><h1>Types of books:</h1>
<table border="2">
<tr>
  <th>Bangla
  <td><form method="post">
<input type="submit"  value="available book" name="submit">
</form></td>
</th>
 </tr>

<tr>
  <th>English
  <td><form method="post">
<input type="submit"  value="available book" name="submit">
</form></td>
</th>
 </tr>

 <tr>
  <th>Math
  <td><form method="post">
<input type="submit"  value="available book" name="submit">
</form></td>
</th>
 </tr>

 <tr>
  <th>Physics
  <td><form method="post">
<input type="submit"  value="available book" name="submit">
</form></td>
</th>
 </tr>

 <tr>
  <th>Chemistry
  <td><form method="post">
<input type="submit"  value="available book" name="submit">
</form></td>
</th>
 </tr>
 
 <tr>
  <th>Biology
  <td><form method="post">
<input type="submit"  value="available book" name="submit">
</form></td>
</th>
 </tr>

 <tr>
  <th>History
  <td><form method="post">
<input type="submit"  value="available book" name="submit">
</form></td>
</th>
 </tr>

 <tr>
  <th>Novel
  <td><form method="post">
<input type="submit"  value="available book" name="submit">
</form></td>
</th>
 </tr>

 <tr>
  <th>Story
  <td><form method="post">
<input type="submit"  value="available book" name="submit">
</form></td>
</th>
 </tr>

 <tr>
  <th>Poem 
  <td><form method="post">
<input type="submit"  value="available book" name="submit">
</form></td>
</th>
 
 
 </tr>



</center>


	  </table>


		
		
		

</body>
</html>