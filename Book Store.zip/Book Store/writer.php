<html>
<head>
<title>home(Book Store)</title>
<style type="text/css">

#start{
background-color:black;
color:pink;
height:20%;
width:100%;
text-align:center;
font-size:40;
 font-family:elephant;
}
  
  
ul{

margin:0px;
padding:0px;
list-style:none;
}




ul li{
	float:left;
	width: 10%;
	height:40px;
	background-color:white; 
	 line-height:40px;
	text-align:center;
	font-size:20px; 
	font-family:Berlin Sans FB;
	margin-right:0px;
	
	}
	
	ul li a{
	text-decoration:none;
	color:brown;
		display:block;
		}


	ul li a:hover{
		background-color:blue;}




ul li ul li{
display:none;
}
ul li:hover ul li{
display:none;
}



a:link,a:visited{
display:block;
color:#FFFFFF;
background-color:#72e47b; 
width:120px;
text-align:center;
padding:5px;
text-transform:uppercase;
text-decoration:none;
}


a:hover{color:#7A991A;font-weight:bold;font-size:110%}
	a:active{color:red;}

li{
float:left;
}










</style>
</head>






<body>

<div id="start">
			Progga's Book Store
			<br>(Writter)</br>
</div>


<ul>
<li><a href="home.php">HOME</a></li>
<li><a href="subject.php">Subject</a></li>
     
<li><a href="writer.php">Writer</a></li>
<li><a href="publisher.html">Publisher</a></li>
<li><a href="order.php">Pre order book</a></li>
<li><a href="mostbook.html">Most sell out book</a></li>
<li><a href="disbook.html">Discount book</a></li>
<li><a href="chibook.html">Children book</a></li>
<li><a href="way.html">Way of getting book</a></li>
<li><a href="contact.html">Contact</a></li>
</ul>

<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<center>

<?php

$user='root';
$pass='';
$db='book_store';

$conn=mysqli_connect("localhost","root","");
mysqli_select_db($conn,"book_store");
$output ='';
//collect
if(isset($_POST['search'])){
	$searchq=$_POST['search'];
		$searchq=preg_replace("#[^0-9a-z ]#i","",$searchq);
	$query=mysqli_query($conn,"SELECT * FROM book WHERE name LIKE '$searchq%' OR writter LIKE '$searchq%' ")or die("could not search!");
		$count=mysqli_num_rows($query);
		if($count==0){
			$output='There was no search results!';
		}else{
			while($row=mysqli_fetch_array($query)){
				$fname=$row['name'];
					$lname=$row['writter'];
				$id=$row['book_id'];
						$output .='<div>'.$fname.' '.$lname.'</div>';
			}
		}
}
?> 

<html>
<head>
<title>
Search
</title>
</head>
<body>
<form action="find.php"method="POST">
<input type="text" name="search"placeholder="Search for writer..."/>
<input type="submit" value=">>"/>
</form>

<?php print("$output");?>
</body>
</html>

		
</center>		
		

</body>
</html>